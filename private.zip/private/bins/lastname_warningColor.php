<style>
    #lastname{
        border-color: red;
    }
</style>