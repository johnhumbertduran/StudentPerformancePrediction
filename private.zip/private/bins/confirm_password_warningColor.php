<style>
    #confirm_password{
        border-color: red;
    }
</style>