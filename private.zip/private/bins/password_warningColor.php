<style>
    #initial_password{
        border-color: red;
    }
</style>