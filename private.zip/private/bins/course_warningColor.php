<style>
    #course{
        border-color: red;
    }
</style>