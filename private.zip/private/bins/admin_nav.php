<nav class="navbar navbar-expand-md bg-info navbar-dark">
  <!-- <a class="navbar-brand" href="#">Navbar</a> -->
<div class="input-group form-inline col-sm-4">
<input class="form-control" type="text" placeholder="Search...">
<div class="input-group-append">
<button class="btn btn-success">Search</button>
</div>
</div>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item home_active">
        <a class="nav-link pl-2" href="../admin">Home</a>
      </li>
      <li class="nav-item student_performance_active">
        <a class="nav-link pl-2" href="studentperformance">Student Performance</a>
      </li>
      <li class="nav-item">
        <a class="nav-link pl-2" href="#">Prediction</a>
      </li>    
      <li class="nav-item">
        <a class="nav-link pl-2" href="#">View Charts</a>
      </li>    
      <li class="nav-item register_active">
        <a class="nav-link pl-2" href="register">Register</a>
      </li>    
      <!-- <li class="nav-item input_grade">
        <a class="nav-link pl-2" href="inputgrade">Input Grade</a>
      </li>     -->
      <li class="nav-item">
        <a class="nav-link pl-2" href="logout.php">Log Out</a>
      </li>    
    </ul>
  </div>  
</nav>